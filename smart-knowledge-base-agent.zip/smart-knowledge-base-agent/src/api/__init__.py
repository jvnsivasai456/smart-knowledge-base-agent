# Init for api module
